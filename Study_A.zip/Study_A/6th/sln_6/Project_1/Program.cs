﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //배열 : 같은 데이터 타입을 가진 데이터들의 집합(고정)
            int[] alphas = new int[3] { 11, 22, 33 };

            foreach (int item in alphas)
            {
                Console.WriteLine(item);
            }




        }
    }
}
