﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //C#에서 문자열 서식화에 사용할 수 있는 방법 두 가지
            //① string 형식의 Format() 메서드
            //② 문자열 보간(Interpolation)
            Console.WriteLine("Total : {0}", 456);
            Console.WriteLine("Total : {0, -10:D}", 456);
            Console.WriteLine("Total : {0, 10:D}", 456);
            Console.WriteLine("Total : {0, 10:x}",255);
            Console.WriteLine("Total : {0:N}", 123456789);
            Console.WriteLine("Total : {0:N0}", 123456789);
            Console.WriteLine("Total : {0:F}", 123.45);


        }
    }
}
