﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class Parent
    {
        public Parent()
        {
            Console.WriteLine("Parent()");
        }
        public Parent(int param) 
        {
            Console.WriteLine("Parent(int param)");
        }
        public Parent(string param) 
        {
            Console.WriteLine("Parent(string param)");
        }

    }
}
