﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_2
{
    internal class Cat : Animal
    {
        public void Meow() { Console.WriteLine("냥냥"); }
    }
}
