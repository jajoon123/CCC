﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //다형성
            //코드 중복을 해결할 수 있는 것
            //다형성은 하나의 클래스가 여러 형태로 변환될 수 있는 성질
            //자식 클래스가 부로 클래스로 위장하는 것
            //기반 클래스와 파생 클래스 사이의 형식 변환 is, as

            /*List<Dog> Dogs = new List<Dog>() { new Dog(), new Dog(), new Dog() };
            List<Cat> Cats = new List<Cat>() { new Cat(), new Cat(), new Cat() };

            foreach (var item in Dogs)
            {
                item.Eat();
                item.Sleep();
                item.Bark();
            }

            foreach (var item in Cats)
            {
                item.Eat();
                item.Sleep();
                item.Meow();
            }
            Console.WriteLine();*/

            List<Animal> Animals = new List<Animal>() 
            { 
                new Dog(), new Cat(), new Dog(), new Cat(),
                new Cat(), new Cat(), new Dog(), new Cat()
            };

            foreach (var item in Animals)
            {
                item.Eat();
                item.Sleep();

                //((Dog)item).Bark();
                //((Cat)item).Meow();

                //is 키워드를 사용하는 경우의 일반적인 형태
                //자료형 변환과 메서드 호출 - 자료형 변환 : (클래스)변수

                if (item is Dog) { ((Dog)item).Bark(); }
                if(item is Cat) { ((Cat)item).Meow();}

                //as 키워드를 사용하는 경우의 일반적인 형태

                var dog = item as Dog;
                if(dog != null) { dog.Bark(); }

                var cat = item as Cat;
                if(cat != null) { cat.Meow(); }

            }
            Console.WriteLine();

            //강제 자료형 변환
            var a = (int)10.1;
            Console.WriteLine(a);
            Console.WriteLine();











        }
    }
}
