﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class MainApp
    {
        public static int Plus(int x, int y) //클래스 메서드
        {
            Console.WriteLine("Calling int Plus(int, int)");
            return x + y;
        }

        public static int Plus(int x, int y, int z) //클래스 메서드
        {
            Console.WriteLine("Calling int Plus(int, int, int)");
            return x + y + z;
        }

        public static double Plus(double x, double y) //클래스 메서드
        {
            Console.WriteLine("Calling double Plus(double, double)");
            return x + y;
        }

        public static double Plus(int x, double y) //클래스 메서드
        {
            Console.WriteLine("Calling double Plus(int, double)");
            return x + y;
        }

    }
}
