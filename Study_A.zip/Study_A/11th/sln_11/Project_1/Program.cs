﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyClassA objA = new MyClassA();
            objA.myField = 15;
            Console.WriteLine(objA.myField);
            Console.WriteLine();

            MyClassB objB = new MyClassB();
            //objB.myField(15);
            //objB.GetMyField(25);
            objB.SetMyField(25);
            Console.WriteLine(objB.GetMyField());
            Console.WriteLine();

            MyClassC objC = new MyClassC();
            //objC.myField = 35;
            objC.MyField = 35;
            Console.WriteLine(objC.MyField);
            Console.WriteLine();

            MyClassD objD = new MyClassD();
            objD.MyField = 45;
            Console.WriteLine(objD.MyField);






        }
    }
}
