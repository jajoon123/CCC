﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class MyClassD
    {
        //간단한 속성 생성 방법
        //private int myField;
        public int MyField { get; set; }
    }
}
