﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine(445);
            WriteLine('a');
            Console.WriteLine("System");
            Console.WriteLine();

            Console.WriteLine(10 + 20 + 30);
            Console.WriteLine("10" + "20" + "30");

            //복합대입 연산자
            int input = 0;
            input += 52; //input = input + 52;

            //증감 연산자
            int num = 10;
            num++; 
            Console.WriteLine(num); //11
            num--;
            Console.WriteLine(num); //10
            Console.WriteLine();

            Console.WriteLine(num++); //10 -> 11
            Console.WriteLine(num++); //11 -> 12
            Console.WriteLine(++num); //13
            Console.WriteLine(--num); //12
            Console.WriteLine();

            //자료형
            int _int = 273;
            long _long = 5227L;
            float _float = 52.273F;
            double _double = 52.273;
            char _char = '글';
            string _string = "문자열";
            Console.WriteLine();

            Console.WriteLine(_int.GetType());
            Console.WriteLine("문자열".GetType());







        }
    }
}
