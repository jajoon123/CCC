﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //③ 서로 다른 파일에 클래스 생성

            Product product = new Product();
            //클래스이름 인스턴스 대입(할당)연산자 메모리할당연산자 생성자

            //product.name = "사과";
            //product.price = 1000;

            Product productA = new Product() { name = "사과", price = 1000 };
            Product productB = new Product() { name = "토마토", price = 2000 };

            //int[] intArray = new int[3] { 10, 20, 30 };

            Console.WriteLine(productA.name + ":" + productA.price + "원");
            Console.WriteLine(productB.name + ":" + productB.price + "원");
            Console.WriteLine("{0} : {1}", productB.name, productB.price);
            Console.WriteLine($"{productB.name} : {productB.price}");

            Cat Kitty = new Cat("키티", "흰색");
            Kitty.Meow();
            Console.WriteLine("{0} : {1}", Kitty.Name, Kitty.Color);
            Console.WriteLine();
            Cat nero = new Cat("네로", "검은색");
            nero.Meow();
            Console.WriteLine($"{nero.Name} : {nero.Color}");


        }
    }
}
