﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3
{
    internal class Product
    {
        public string name; //필드(변수)
        public int price;
    }
}
