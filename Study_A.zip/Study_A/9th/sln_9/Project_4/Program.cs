﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Random 클래스
            Random random = new Random();

            //기본
            Console.WriteLine(random.Next()); //임의의 정수값 반환

            //특정 범위 내에 난수 생성
            Console.WriteLine(random.Next(1, 10)); //1부터 9까지의 난수 반환
            Console.WriteLine(random.NextDouble());
            Console.WriteLine(random.NextDouble() * 10);

            //List 클래스
            List<int> list = new List<int>() { 52, 85, 273, 64};
            list.Add(300);
            list.Remove(85);
            list.RemoveAt(2);

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            //Math 클래스
            Console.WriteLine(Math.Abs(-25));
            Console.WriteLine(Math.Round(52.573));
            Console.WriteLine(Math.Min(52, 273));
            Console.WriteLine(Math.PI);


        }
    }
}
