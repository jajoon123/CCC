﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_3
{
    internal class Program
    {
        class Product
        {
            public string Name { get; set; }
            public int Price { get; set; }
        }

        static int SortWithName(Product a, Product b)
        {
            //return a.Name.CompareTo(b.Name); //오름차순
            return b.Name.CompareTo(a.Name); //내림차순
        }

        static void Main(string[] args)
        {
            //리스트 생성
            List<Product> products = new List<Product>()
            {
                new Product() {Name = "사과", Price = 600},
                new Product() {Name = "포도", Price = 700},
                new Product() {Name = "딸기", Price = 500},
                new Product() {Name = "망고", Price = 800},
                new Product() {Name = "앵두", Price = 400}
            };

            //정렬
            products.Sort(SortWithName);

            //출력
            foreach (var item in products)
            {
                Console.WriteLine(item.Name + " : " + item.Price);
            }
        }
    }
}
