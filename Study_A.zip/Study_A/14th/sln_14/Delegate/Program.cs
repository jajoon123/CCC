﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    delegate int MyDelegate(int a, int b);

    class Calculator
    {
        public int Plus(int a, int b) //인스턴스 메서드
        {
            return a + b;
        }

        public static int Minus(int a, int b) //클래스 메서드
        {
            return a - b;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //델리게이트(대리자)
            //대리자는 메서드를 참조하기 위한 기법으로
            //이벤트와 스레드를 처리하는데 주로 사용
            //델리게이트 정의 
            //접근제한자 delegate 반환형 델리게이트 이름 반환형
            //대리자를 이용하여 콜백을 구현하는 과정
            //① 대리자를 선언한다.
            //② 대리자의 인스턴스를 생성한다.
            //③ 대리자를 호출한다.

            Calculator Calc = new Calculator(); //클래스 인스턴스
            MyDelegate Callback; // 델리케이트(대리자) 인스턴스

            Callback = Calc.Plus;
            Console.WriteLine(Callback(5, 3));
            Callback = new MyDelegate(Calc.Plus);
            Console.WriteLine(Callback(10, 3));

            Callback = Calculator.Minus;
            Console.WriteLine(Callback(5, 3));
            Callback = new MyDelegate(Calculator.Minus);
            Console.WriteLine(Callback(10, 3));
        }
    }
}
