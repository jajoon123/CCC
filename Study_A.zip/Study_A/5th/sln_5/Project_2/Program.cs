﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("나이 입력 : ");
            int age = int.Parse(Console.ReadLine());
            if (age >= 18)
            {
                Console.WriteLine("성인");
            }
            else
            {
                Console.WriteLine("미성년자");
            }

            Console.WriteLine("숫자 입력 : ");
            int input = int.Parse(Console.ReadLine());
            if(input % 2 == 0)
            {
                Console.WriteLine("짝수");
            }
            else
            {
                Console.WriteLine("홀수");
            }

            switch (input % 2)
            {
                case 0:
                    Console.WriteLine("짝수");
                    break;
                case 1:
                    Console.WriteLine("홀수");
                    break;
            }*/

            //string input = Console.ReadLine();
            //int number = int.Parse(input);
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(number % 2 ==0 ? true : false);
            Console.WriteLine(number % 2 ==0 ? "짝수" : "홀수");



        }
    }
}
