﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace A_Image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // [추가] 이벤트 연결(디자이너에서 이미 연결돼 있으면 중복 호출 안 됨)
            this.Load += Form1_Load;
            this.btnNext.Click += btnNext_Click;
        }

        int ImgCount = 0; //이미지 번호

        private void Form1_Load(object sender, EventArgs e)
        {
            // [추가] 이미지가 하나도 없으면 버튼 비활성화 후 반환
            if (ImgList.Images.Count == 0)
            {
                btnNext.Enabled = false;
                return;
            }

            // [추가] 보기 좋게
            picImg.SizeMode = PictureBoxSizeMode.StretchImage;

            // [수정] 캐스팅(환경에 따라 필요)
            this.picImg.Image = (Image)this.ImgList.Images[0];
            ImgCount = this.ImgList.Images.Count;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            // [추가] 가드
            if (ImgList.Images.Count == 0) return;

            ImgCount--;
            if (ImgCount < 0)
            {
                ImgCount = this.ImgList.Images.Count - 1;
            }

            // [수정] 캐스팅(환경에 따라 필요)
            this.picImg.Image = (Image)this.ImgList.Images[ImgCount];
        }
    }
}
