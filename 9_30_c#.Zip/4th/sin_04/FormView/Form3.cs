﻿using System;
using System.Windows.Forms;

namespace FormView
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        public string SetText
        {
            set { this.Text = value; }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.Opacity = 1.0;

         
            this.Timer.Enabled = true;   
        }


        private void Timer_Tick(object sender, EventArgs e)
        {
            const int targetW = 320;
            const int targetH = 220;

   
            int newW = this.Width < targetW ? this.Width + 12 : this.Width;
            int newH = this.Height < targetH ? this.Height + 8 : this.Height;

            this.Size = new System.Drawing.Size(newW, newH);

            if (this.Width >= targetW && this.Height >= targetH)
            {
                this.Timer.Enabled = false;
            }
        }
    }
}
