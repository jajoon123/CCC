﻿using System;
using System.Windows.Forms;

namespace FormView
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private double o = 0.0; 

        public string SetText
        {
            set { this.Text = value; }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Opacity = 0.0;
            this.Timer.Enabled = true;   
        }


        private void Timer_Tick(object sender, EventArgs e)
        {
            if (o < 100.0)
            {
                o += 5.0;            
                this.Opacity = o / 100.0;
            }
            else
            {
                this.Opacity = 1.0;
                this.Timer.Enabled = false; 
            }
        }
    }
}
