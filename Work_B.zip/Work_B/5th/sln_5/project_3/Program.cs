﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //배열을 초기화 하는 방법 네 가지
            int[] scores = new int[5];
            scores[0] = 10;
            scores[1] = 20;
            scores[2] = 30;
            scores[3] = 40;
            scores[4] = 50;
            foreach (var score in scores)
            {
                Console.WriteLine(score);
            }

            int[] scores1 = new int[5] { 10, 20, 30, 40, 50 };
            int[] scores2 = new int[] { 10, 20, 30, 40, 50 };
            //int[] scores3 = int[] { 10, 20, 30, 40, 50 };
            int[] scores4 = { 10, 20, 30, 40, 50 };

            List<int> lists = new List<int>() { 10, 20, 30 };







        }
    }
}
