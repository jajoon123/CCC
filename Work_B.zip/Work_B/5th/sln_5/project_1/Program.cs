﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("이름 입력 : ");
            string name = Console.ReadLine();
            Console.WriteLine("나이 입력 : ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("name님의 5년 후 나이는 " + (age + 5));
            Console.WriteLine("{0}님의 5년 후 나이는 {1}살 입니다.", name, age);
            Console.WriteLine($"{name}님의 5년 후 나이는 {age}살 입니다.");*/

            Console.WriteLine("원의 반지름 입력 : ");
            double radius = double.Parse(Console.ReadLine());
            Console.WriteLine("원의 둘레 : " + (2*3.14*radius));
            Console.WriteLine($"원의 둘레 : {(2*3.14*radius)}"); //보간법
            Console.WriteLine("원의 넓이 : " + (2* radius* radius));
            Console.WriteLine($"원의 넓이 : {(2* radius* radius)}");



        }
    }
}
