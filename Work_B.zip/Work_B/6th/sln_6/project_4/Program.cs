﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("이번 달은 몇 월인가요~");
            int input = int.Parse(Console.ReadLine());

           if(3 <= input && input <= 5)
            {
                Console.WriteLine("봄입니다.");
            }
            else if(6 <= input && input <= 8)
            {
                Console.WriteLine("여름입니다.");
            }
            else if(9 <= input && input <= 11)
            {
                Console.WriteLine("가을입니다.");
            }
            else if(12 == input || input <= 2)
            {
                Console.WriteLine("겨울입니다.");
            }
            else
            {
                Console.WriteLine("어느 별에 살고 계신가요~");
            }*/

            Console.WriteLine("이번 달은 몇 월인가요~");
            int input = int.Parse(Console.ReadLine());

            if( input >= 13 || input <= 0)
            {
                Console.WriteLine("잘못된 입력");
            }

            else if (input == 12)
            {
                Console.WriteLine("겨울입니다.");
            }

            else if(input >= 9)
            {
                Console.WriteLine("가을입니다.");
            }
            else if (input >= 6)
            {
                Console.WriteLine("여름입니다.");
            }
            else if (input >= 3)
            {
                Console.WriteLine("봄입니다.");
            }
            else if (input >= 1)
            {
                Console.WriteLine("겨울입니다.");
            }
            else
            {
                Console.WriteLine("어느 별에 살고 계신가요~");
            }


        }
    }
}
