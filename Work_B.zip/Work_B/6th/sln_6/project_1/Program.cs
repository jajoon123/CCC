﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //배열 : 같은 데이터 타입을 가진 데이터들의 집합(고정)
            //int[] alphas = new int[3] { 10, 20, 30 };            
            //int[] alphas = new int[] { 10, 20, 30 };
            
            int[] alphas = { 10, 20, 30 };
            foreach (int alpha in alphas)
            {
                Console.WriteLine(alpha);
            }
            Console.WriteLine();

            //리스트 : 같은 데이터 타입을 가진 데이터들의 집합(가변)
            /*List<int> lists = new List<int>();
            lists.Add(10);
            lists.Add(20);
            lists.Add(30);

            foreach (var item in lists)
            {
                Console.WriteLine(item);
            }*/

            List<int> lists = new List<int>() {10, 20, 30};
            lists.Add(40);
            lists.Add(50);
            lists.Add(60);
            lists.Remove(60);
            lists.RemoveAt(0);
            lists.Insert(0, 5);



            foreach (var item in lists)
            {
                Console.WriteLine(item);
            }




        }
    }
}
