﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //C#에서문자열 서식화에 사용할 수 있는 간편한 방법 두 가지
            //① string 형식의 Format() 메서드
            //② 문자열 보간(Interpolation)

            Console.WriteLine("Total : {0, -7:D}", 123);
            Console.WriteLine("Total : {0, 7:D}", 123);
            Console.WriteLine("{0:N0}", 123456789);
            Console.WriteLine("{0:F}", 123.45);
            Console.WriteLine();

            Console.WriteLine($"Total : {123, -7:D}");



        }
    }
}
