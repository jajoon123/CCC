﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    class Program
    {
        //var global = 52;

        static void Main(string[] args)
        {
            //Console.WriteLine("float : " + sizeof(float));
            //Console.WriteLine("string : " + sizeof(String));

            //var 키워드 : 변수의 자료형을 자동으로 지정
            //var 사용의 조건
            //① 지역 변수 : 메서드 내부에 선언되어 있는 변수
            //② 변수 선언과 동시에 초기화 수행

            var number1 = 100; //int 자료형
            var number2 = 100L; //long 자료형
            var number3 = 100.13; //double 자료형
            var number4 = 100.13F; //float 자료형

            //입력
            /*string input1 = Console.ReadLine(); //10
            Console.WriteLine(input1 + input1); //문자열 연결 연산자 -> 1010*/

            //숫자와 문자열 덧셈
            /*Console.WriteLine(52 + 273); //325 -> 덧셈 연산자
            Console.WriteLine("52" + 273); //52273 -> 문자열 연결 연산자
            Console.WriteLine("52" + "273"); //52273 -> 문자열 연결 연산자*/

            //자료형 변환
            //① 강제 자료형 변환
            /*var a1 = 10.5;
            var a2 = (int)10.5;
            Console.WriteLine(a1);
            Console.WriteLine(a2);

            //다른 자료형을 숫자로 변환
            //② 문자열을 숫자로 변환
            Console.WriteLine("52");
            Console.WriteLine(("52").GetType());
            Console.WriteLine(int.Parse("52"));
            Console.WriteLine(int.Parse("52").GetType());
            Console.WriteLine(float.Parse("52.273"));
            Console.WriteLine(float.Parse("52.273").GetType());

            //③ 다른 자료형을 문자열로 변환
            //기본 자료형을 문자열로 변환
            Console.WriteLine((52.273).ToString());
            Console.WriteLine('a' + 'b'); //195
            Console.WriteLine(('a').ToString());*/

            //문제: inch 단위를 입력받아 cm 단위를 구하는 코드 작성
            //1inch = 2.54cm

            Console.WriteLine("inch를 입력하세요 : ");
            double inch = double.Parse(Console.ReadLine());
            Console.WriteLine(inch + "inch는 " + (inch * 2.54) + "cm입니다.");




        }
    }
}
