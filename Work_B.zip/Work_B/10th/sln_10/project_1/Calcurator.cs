﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    internal class Calcurator
    {
        public static int Plus(int x, int y) {  return x + y; }
        public static int Minus(int x, int y) {  return x - y; }
    }
}
