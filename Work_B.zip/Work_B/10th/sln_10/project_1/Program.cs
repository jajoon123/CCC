﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //인스턴스 메서드 생성
            Test test = new Test();
            Console.WriteLine(test.Power(10));
            Console.WriteLine(test.Power(15));
            //Console.WriteLine(Test.Power(15));

            //클래스 메서드 생성
            //MyMath myMath = new MyMath();
            Console.WriteLine(MyMath.Abs(-52));

            int resultA = Calcurator.Plus(3, 4);
            Console.WriteLine(resultA);

            int resultB = Calcurator.Minus(5, 3);
            Console.WriteLine(resultB);

             List<Student> list = new List<Student>() 
             {
                 new Student() {name = "홍길동", grade = 1},
                 new Student() {name = "유산슬", grade = 2},
                 new Student() {name = "강호돌", grade = 3},
             };

            foreach (var item in list)
            {
                Console.WriteLine(item.name + " : " + item.grade);
            }


        }
    }
}
