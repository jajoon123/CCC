﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            //기본
            Console.WriteLine(random.Next());//임의의 정수값 반환

            //특정 범위 내에 난수 생성
            Console.WriteLine(random.Next(1, 10));
            Console.WriteLine(random.NextDouble());
            Console.WriteLine(random.NextDouble() * 10);

            //배열
            int[] number = {1, 2, 3, 4, 5};
            int[] numbers = {1, 2, 3, 4, 5};

            string[] stringArray = new string[3] { "사과", "배", "포도" };
            foreach (string item in stringArray)
            {
                Console.WriteLine(item);
            }


        }
    }
}
