﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2
{
    internal class Program
    {
        //② 클래스 생성 : 클래스 내에 여러개의 클래스 생성
        class Book
        {
            public string Title;
            public string Writer;
            public string Publisher;
            public int Published_Date;
        }

        class Product
        {
            public string name;
            public int price;
        }

        class Car
        {
            public void Hi() { Console.WriteLine("안녕"); }
            public void Go() { Console.WriteLine("전진"); }
        }

        static void Main(string[] args)
        {
            Book book1 = new Book();
            //클래스이름 인스턴스 대입(할당)연산자) 메모리할당연산자 생성자
            book1.Title = "폭삭 속았수다";
            book1.Writer = "홍길동";
            book1.Publisher = "(도)유한";
            book1.Published_Date = 20250429;

            Console.WriteLine("제목 : " + book1.Title);
            Console.WriteLine("제목 : {0}", book1.Title);
            Console.WriteLine($"제목 : {book1.Title}");

            Product product = new Product();
            //product.name = "감자";
            //product.price = 5000;

            Product product1 = new Product() { name = "감자", price = 5000 };
            Product product2 = new Product() { name = "고구마", price = 6000 };
            Console.WriteLine(product1.name + ":" + product1.price + "원");
            Console.WriteLine("{0} : {1}원", product1.name, product1.price);
            Console.WriteLine($"{product1.name} : {product1.price}원");
            Console.WriteLine(product2.name + ":" + product2.price + "원");

            Car car = new Car();
            car.Hi();
            car.Go();


        }
    }
}
