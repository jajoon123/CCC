﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class MyClassC
    {
        //일반적인 속성 생성 방법 - get과 set 접근자를 사용하여 속성 선언
        private int myField; //필드(변수), backing field
        public int MyField //속성 이름
        {
            get { return myField; }
            set { myField = value; } //value는 set 접근자의 암묵적 매개변수로 간주
        }
    }
}
