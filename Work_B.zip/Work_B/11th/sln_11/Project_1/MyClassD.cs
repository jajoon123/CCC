﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class MyClassD
    {
        //긴단한 속성 생성 방법(자동 구현 속성)
        //private int myField;
        public int MyField { get; set; }
    }
}
