﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyClassA A_obj = new MyClassA();
            A_obj.myField = 10;
            Console.WriteLine(A_obj.myField);
            Console.WriteLine();

            MyClassB B_obj = new MyClassB();
            B_obj.SetMyField(20);
            Console.WriteLine(B_obj.GetMyField());
            Console.WriteLine();

            MyClassC C_obj = new MyClassC();
            C_obj.MyField = 30;
            Console.WriteLine(C_obj.MyField);
            Console.WriteLine();

            MyClassD D_obj = new MyClassD();
            D_obj.MyField = 40;
            Console.WriteLine(D_obj.MyField);

        }
    }
}
