﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    internal class MyClassB
    {
        private int myField; //필드(변수), backing field
        public int GetMyField() { return myField; }
        public void SetMyField(int NewValue) { myField = NewValue; }
    }
}
