﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BoxA boxA = new BoxA(10, 10);
            boxA.width = -10;
            Console.WriteLine(boxA.Area());
            Console.WriteLine();

            BoxB boxB = new BoxB(20, 20);
            //boxB.width = -20;
            Console.WriteLine(boxB.Area());
            Console.WriteLine();

            BoxC boxC = new BoxC(30, 30);
            boxC.SetWidth(-15);
            boxC.SetHeight(15);
            Console.WriteLine(boxC.Area());
            Console.WriteLine();

            BoxD boxD = new BoxD(40, 40);
            Console.WriteLine(boxD.Area());
            boxD.Width = -10;
            boxD.Height = 10;
            Console.WriteLine(boxD.Area()); //-100

            BoxE boxE = new BoxE(40, 40);
            Console.WriteLine(boxE.Area());
            boxD.Width = -10;
            boxD.Height = 10;
            Console.WriteLine(boxE.Area()); //-100


        }
    }
}
