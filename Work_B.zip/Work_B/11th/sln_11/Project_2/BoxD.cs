﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class BoxD
    {
        //일반적인 속성 생성 방법
        //get과 set 접근자를 사용하여 속성 선언

        private int width; //필드(변수)
        public int Width
        {
            get { return width; }
            //set { width = value; }
            set 
            {
                if (width > 0) { width = value; }
                else { Console.WriteLine("너비를 자연수로 입력해 주세요."); }
            }
        }

        private int height;
        public int Height
        {
            get { return height; }
            //set { height = value; }
            set
            {
                if (height > 0) { height = value; }
                else { Console.WriteLine("높이를 자연수로 입력해 주세요."); }
            }
        }

        public int Area() //메서드
        {
            return this.width * this.height;
        }

        public BoxD(int width, int height) //생성자
        {
            /*this.width = width;
            this.height = height;*/
            Width = width;
            Height = height;
        }

    }
}
