﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class BoxE
    {
        //간편한 속성 생성(자동 구현 속성)

        //private int width;
        public int Width { get; set; }

        //private int height;
        public int Height { get; set; }

        public int Area() //메서드
        {
            //return this.width * this.height;
            return Width * Height;
        }

        public BoxE(int width, int height) //생성자
        {
            Width = width;
            Height = height;
        }


    }
}
