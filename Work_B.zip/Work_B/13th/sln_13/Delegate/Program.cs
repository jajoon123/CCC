﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    delegate int MyDelegate(int a, int b);
    class Calculator
    {
        public int Plus(int a, int b)
        {
            return a + b;
        }
        public static int Minus(int a, int b)
        {
            return a - b;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Calculator Calc = new Calculator(); //클래스 인스턴스
            MyDelegate Callback; //델리게트(대리자)의 인스턴스

            Callback = new MyDelegate(Calc.Plus);
            Console.WriteLine(Callback(4, 3));

            //Callback = new MyDelegate(Calc.Minus);
            Callback = new MyDelegate(Calculator.Minus);
            Console.WriteLine(Callback(4, 3));

        }
    }
}
