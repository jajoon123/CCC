﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingCallback
{
    delegate int Compare(int a, int b);

    internal class Program
    {
        static int AscendCompare(int a, int b)
        {
            if (a > b) { return 1; }
            else if (a == b) { return 0; }
            else { return -1; }

        }

        static int DescendCompare(int a, int b)
        {
            if (a < b) { return 1; }
            else if (a == b) { return 0; }
            else { return -1; }
        }

        static void BubbleSort(int[] DataSet, Compare Comparer)
        {
            int i = 0; //바깥쪽 루프 인덱스
            int j = 0; //안쪽 루 인덱스
            int temp = 0; //

            for (i = 0; i < DataSet.Length - 1; i++) //전체 pass수
            {
                for (j = 0; j < DataSet.Length - (i + 1); j++) //인접한 요소 비교
                {
                    if (Comparer(DataSet[j], DataSet[j + 1]) > 0)
                    {
                        temp = DataSet[j + 1];
                        DataSet[j + 1] = DataSet[j];
                        DataSet[j] = temp;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            int[] array1 = { 3, 7, 4, 2, 10 };
            Console.WriteLine("Sorting ascending...");
            BubbleSort(array1, new Compare(AscendCompare));

            for (int i = 0; i < array1.Length; i++)
            {
                Console.WriteLine($"{array1[i]}");
            }
            Console.WriteLine();




        }
    }
}
