﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_1
{
    delegate int MyDelegate(int a, int b);  //델리게이트(대리자) 선언

    class Calculator
    {
        public int Plus(int a, int b)
        {
            return a + b;
        }

        //public static int Minus( int a, int b )
        public int Minus(int a, int b)
        {
            return a - b;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //델리게이트(대리자)
            //메서드를 참조하기 위한 기법으로 
            //이벤트와 스레드를 처리하는 데 주로 사용된다.
            //정의 : 접근제한자 delegate 반환형 델리게이트 이름
            //델리게이트 이름은 첫글자를 대문자로쓰는 것이 관례
            //델리게이트를 정의하기 위해서는 먼저 델리게이트의 
            //메서드 형태를 알아야 한다.
            //메서드의 반환형, 매개변수의 개수와 타입을 정확하게
            //일치시켜야 한다.
            //대리자를 이용하여 콜백을 구현하는 과정
            //① 대리자를 선언한다.
            //② 대리자의 인스턴스를 생성한다.
            //③ 대리자를 호출한다.

            Calculator Calc = new Calculator(); //클래스의 인스턴스
            MyDelegate Callback;  //델리게이트(대리자)의 인스턴스

            Callback = new MyDelegate(Calc.Plus);
            Console.WriteLine(Callback(3, 4));

            //Callback = new MyDelegate( Calculator.Minus );
            Callback = new MyDelegate(Calc.Minus);
            Console.WriteLine(Callback(7, 5));
        }
    }
}
