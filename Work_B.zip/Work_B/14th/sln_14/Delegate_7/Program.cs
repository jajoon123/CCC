﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_7
{
    internal class Program
    {
        class Product
        {
            public string Name { get; set; }
            public int Price { get; set; }
        }

        static void Main(string[] args)
        {
            //리스트 생성
            List<Product> products = new List<Product>()
            {
                new Product() {Name = "감자", Price = 600},
                new Product() {Name = "당근", Price = 500},
                new Product() {Name = "양파", Price = 400},
                new Product() {Name = "배추", Price = 700},
                new Product() {Name = "상추", Price = 300}
            };

            //간단한 형태의 람다 사용
            products.Sort( (a, b) => { return a.Price.CompareTo(b.Price); });
            products.Sort( (a, b) => a.Price.CompareTo(b.Price) );

            //출력
            foreach (var item in products)
            {
                Console.WriteLine(item.Name + " : " + item.Price);
                //Console.WriteLine("{0} : {1}", item.Name, item.Price);
                //Console.WriteLine($"{item.Name} : {item.Price}");
            }
        }
    }
}
