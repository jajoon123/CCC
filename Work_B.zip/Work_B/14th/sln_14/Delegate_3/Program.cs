﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_3
{
    delegate int Compare(int a, int b);

    internal class Program
    {
        static void BubbleSort(int[] DataSet, Compare Comparer)
        {
            int i = 0;
            int j = 0;
            int temp = 0;

            for (i = 0; i < DataSet.Length - 1; i++) //전체 Pass수
            {
                for (j = 0; j < DataSet.Length - (i + 1); j++) //인접한 요소 비교
                {
                    if (Comparer(DataSet[j], DataSet[j + 1]) > 0)
                    {
                        temp = DataSet[j + 1];
                        DataSet[j + 1] = DataSet[j];
                        DataSet[j] = temp;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            //무명(익명) 메서드 : 이름이 없는 메서드
            //사용하는 이유 : 
            //코드의 간결성, 가독성 향상
            //특정한 상황에서만 사용되는 임시적인 로직 처리
            //코드의 간결성과 즉시성 :
            //메서드를 따로 정의할 필요가 없다.
            //이벤트 핸들러, 콜백함수

            int[] array1 = { 3, 7, 4, 2, 10 };
            Console.WriteLine("Sorting ascending...");
            BubbleSort(array1, delegate(int a, int b)
            {
                if (a > b) { return 1; }
                else if (a == b) { return 0; }
                else { return -1; }
            } );

            for (int i = 0; i < array1.Length; i++)
                Console.Write($"{array1[i]} ");
            Console.WriteLine();

            int[] array2 = { 7, 2, 8, 10, 11 };
            Console.WriteLine("\nSorting descending...");
            BubbleSort(array2, delegate (int a, int b) 
            {
                if (a < b) { return 1; }
                else if (a == b) { return 0; }
                else { return -1; }
            });

            for (int i = 0; i < array2.Length; i++)
                Console.Write($"{array2[i]} ");




        }
    }
}
