﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    internal class Program
    {
        class Person { public string name; }

        static void Main(string[] args)
        {
            //값 복사(Value Copy)와 참조 복사(Reference Copy)
            //값 복사와 참조 복사는 메모리 동작 방식에 중요한 차이를 보이며,
            //프로그램 동작과 성능에 큰 영향을 미친다.

            //① 값 타입 복사 : int, float, char, bool, struct
            int a = 10;
            int b = a;
            b = 20;
            Console.WriteLine(a); //10
            Console.WriteLine(b); //20

            //② 참조 타입 복사 : class, array, string, delegate, object
            Person p1 = new Person();
            p1.name = "Hong";

            Person p2 = p1;
            p2.name = "Yook";
            Console.WriteLine(p1.name);
            Console.WriteLine(p2.name);



        }
    }
}
