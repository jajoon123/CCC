﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //오버로딩 : 하나의 메서드 이름에 여러 개의 구현을 올리는 것
            //이름과 매개변수를 가지고 프로토타입(코드 기본 모델) 결정

            //int
            Console.WriteLine(MyMath.Abs(50));
            //double
            Console.WriteLine(MyMath.Abs(52.345));
            //long
            Console.WriteLine(MyMath.Abs(21474886));
            Console.WriteLine();

            Console.WriteLine(MainApp.Plus(10, 20));
            Console.WriteLine(MainApp.Plus(10, 20, 30));
            Console.WriteLine();
            Console.WriteLine(MainApp.Plus(10.0, 2.4));
            Console.WriteLine(MainApp.Plus(11, 2.54));

        }
    }
}
