﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BInheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //다형성
            //코드 중복을 해결
            //자식(파생) 클래스가 부모(기반) 클래스로 위장 하는 것
            List<Animal> Animals = new List<Animal>() 
            { new Dog(), new Cat(), new Dog(), new Cat(),
              new Dog(), new Cat(), new Dog(), new Cat()
            };

            foreach (var item in Animals)
            {
                item.Eat();
                item.Sleep();
                /*((Cat)item).Meow();
                ((Dog)item).Bark();*/
                //is키워드를 이용하는 경우의 일반적인 형태
                if(item is Dog) { ((Dog)item).Bark(); }
                if(item is Cat) { ((Cat)item).Meow(); }

                //as 키워드를 사용하는 경우의 일반적인 형태
                var dog = item as Dog;
                if(dog != null) { dog.Bark(); }

                var cat = item as Cat;
                if (cat != null) { cat.Meow(); }
            }
            Console.WriteLine();

            //강제 자료형 변환
            var a = (int)10.01;
            var b = (float)10.01;
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine();







        }
    }
}
