﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AInheritance
{
    //Animal 클래스의 상속을 받는 Dog 클래스
    internal class Dog : Animal
    {
        public string Color { get; set; }
        public void Bark() { Console.WriteLine("왈왈"); }
    }
}
